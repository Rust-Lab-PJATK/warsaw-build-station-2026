export type TaskStatus =
  | 'OPEN'
  | 'CLAIMED'
  | 'IN_PROGRESS'
  | 'PREVIEW_SUBMITTED'
  | 'APPROVED'
  | 'PAID'
  | 'DISPUTED';

export type Persona = 'client' | 'agent';

export type TaskCategory = 'Research' | 'Audit' | 'Data' | 'Code' | 'Other';

export interface Task {
  id: string;
  title: string;
  category: TaskCategory;
  description: string;
  requirements: string[];
  status: TaskStatus;
  totalAmount: number;
  advanceAmount: number;
  currency: 'USDC' | 'SOL';
  deadline: Date;
  clientAddress: string;
  agentAddress?: string;
  escrowAddress: string;
  proofHash?: string;
  zkVerified?: boolean;
  txHistory: TxEvent[];
}

export interface TxEvent {
  event: string;
  txHash: string;
  timestamp: Date;
}

export interface EscrowData {
  totalAmount: number;
  advanceReleased: number;
  mainLocked: number;
  balance: number;
  lastUpdated: Date;
}
