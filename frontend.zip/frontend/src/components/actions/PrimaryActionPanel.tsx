import { motion } from 'framer-motion';
import { Clock, CreditCard } from 'lucide-react';
import type { Persona, TaskStatus } from '../../types';

interface PrimaryActionPanelProps {
  persona: Persona;
  status: TaskStatus;
  amount?: number;
  currency?: string;
  onAction?: (action: string) => void;
}

type Action = {
  primary?: { label: string; action: string };
  secondary?: { label: string; action: string; danger?: boolean };
  waiting?: string;
};

function getActions(persona: Persona, status: TaskStatus, amount = 0, currency = 'USDC'): Action {
  if (persona === 'client') {
    switch (status) {
      case 'OPEN':
        return {
          primary: { label: `Fund Escrow`, action: 'fund_escrow' },
          secondary: { label: 'Edit Task', action: 'edit_task' },
        };
      case 'CLAIMED':
      case 'IN_PROGRESS':
        return {
          waiting: 'Waiting for agent to deliver proof of work…',
          secondary: { label: 'Cancel Task', action: 'cancel_task', danger: true },
        };
      case 'PREVIEW_SUBMITTED':
        return {
          primary: { label: `Approve & Release ${amount} ${currency}`, action: 'approve' },
          secondary: { label: 'Dispute', action: 'dispute', danger: true },
        };
      case 'APPROVED':
      case 'PAID':
        return {
          secondary: { label: 'View Receipt', action: 'view_receipt' },
        };
      case 'DISPUTED':
        return { waiting: 'Dispute resolution in progress…' };
      default:
        return {};
    }
  } else {
    switch (status) {
      case 'OPEN':
        return { primary: { label: 'Claim Task', action: 'claim_task' } };
      case 'CLAIMED':
      case 'IN_PROGRESS':
        return {
          primary: { label: 'Submit Proof', action: 'submit_proof' },
          secondary: { label: 'Release Claim', action: 'release_claim', danger: false },
        };
      case 'PREVIEW_SUBMITTED':
        return { waiting: 'Awaiting client review…' };
      case 'APPROVED':
      case 'PAID':
        return { secondary: { label: 'View Payment', action: 'view_payment' } };
      case 'DISPUTED':
        return { waiting: 'Dispute resolution in progress…' };
      default:
        return {};
    }
  }
}

export function PrimaryActionPanel({
  persona,
  status,
  amount,
  currency,
  onAction,
}: PrimaryActionPanelProps) {
  const actions = getActions(persona, status, amount, currency);

  return (
    <div
      style={{
        background: 'var(--bg-surface)',
        border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-lg)',
        overflow: 'hidden',
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: '14px 16px 12px',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
        }}
      >
        <CreditCard size={12} style={{ color: 'var(--text-muted)' }} />
        <span
          style={{
            fontSize: '11px',
            fontWeight: 600,
            color: 'var(--text-muted)',
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
          }}
        >
          Actions
        </span>
      </div>

      {/* Body */}
      <div style={{ padding: '16px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {/* Waiting state */}
        {actions.waiting && (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '12px',
              background: 'var(--bg-elevated)',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--border-subtle)',
            }}
          >
            <Clock size={13} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
            <span style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
              {actions.waiting}
            </span>
          </div>
        )}

        {/* Primary button */}
        {actions.primary && (
          <motion.button
            whileTap={{ scale: 0.97 }}
            transition={{ duration: 0.1 }}
            onClick={() => onAction?.(actions.primary!.action)}
            style={{
              background: 'var(--accent-primary)',
              color: 'var(--text-inverse)',
              border: 'none',
              borderRadius: 'var(--radius-md)',
              padding: '12px 24px',
              fontSize: '14px',
              fontFamily: 'var(--font-sans)',
              fontWeight: 600,
              cursor: 'pointer',
              width: '100%',
              transition: 'background 150ms ease',
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background =
                'var(--accent-primary-hover)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background = 'var(--accent-primary)';
            }}
          >
            {actions.primary.label}
          </motion.button>
        )}

        {/* Secondary button */}
        {actions.secondary && (
          <motion.button
            whileTap={{ scale: 0.97 }}
            transition={{ duration: 0.1 }}
            onClick={() => onAction?.(actions.secondary!.action)}
            style={{
              background: actions.secondary.danger ? 'transparent' : 'var(--bg-elevated)',
              color: actions.secondary.danger ? 'var(--accent-red)' : 'var(--text-secondary)',
              border: actions.secondary.danger
                ? '1px solid var(--accent-red-dim)'
                : '1px solid var(--border-subtle)',
              borderRadius: 'var(--radius-md)',
              padding: '10px 24px',
              fontSize: '14px',
              fontFamily: 'var(--font-sans)',
              fontWeight: 500,
              cursor: 'pointer',
              width: '100%',
              transition: 'background 150ms ease, color 150ms ease',
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background = actions.secondary!.danger
                ? 'var(--accent-red-dim)'
                : 'var(--bg-overlay)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.background = actions.secondary!.danger
                ? 'transparent'
                : 'var(--bg-elevated)';
            }}
          >
            {actions.secondary.label}
          </motion.button>
        )}
      </div>
    </div>
  );
}
