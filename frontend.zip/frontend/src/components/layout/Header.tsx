import { Link } from 'react-router-dom';
import { Zap } from 'lucide-react';
import { WalletButton } from './WalletButton';
import { PersonaSwitcher } from './PersonaSwitcher';
import type { Persona } from '../../types';

interface HeaderProps {
  persona: Persona;
  onPersonaChange: (p: Persona) => void;
  walletAddress?: string;
}

export function Header({ persona, onPersonaChange, walletAddress }: HeaderProps) {
  return (
    <header
      style={{
        background: 'var(--bg-surface)',
        borderBottom: '1px solid var(--border-subtle)',
        padding: '0 24px',
        height: '56px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        position: 'sticky',
        top: 0,
        zIndex: 50,
        backdropFilter: 'blur(8px)',
      }}
    >
      {/* Left: Logo */}
      <Link
        to="/board"
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          textDecoration: 'none',
        }}
      >
        <div
          style={{
            width: '28px',
            height: '28px',
            background: 'var(--accent-primary-dim)',
            border: '1px solid var(--accent-primary)',
            borderRadius: 'var(--radius-md)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Zap size={14} style={{ color: 'var(--accent-primary)' }} />
        </div>
        <span
          style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '13px',
            fontWeight: 600,
            color: 'var(--text-primary)',
            letterSpacing: '0.02em',
          }}
        >
          AgentMesh
        </span>
      </Link>

      {/* Right: Persona switcher + Wallet */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <PersonaSwitcher persona={persona} onChange={onPersonaChange} />
        <WalletButton address={walletAddress} />
      </div>
    </header>
  );
}
