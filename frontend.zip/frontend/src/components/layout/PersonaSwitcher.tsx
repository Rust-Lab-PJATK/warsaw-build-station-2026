import { motion } from 'framer-motion';
import type { Persona } from '../../types';

interface PersonaSwitcherProps {
  persona: Persona;
  onChange: (p: Persona) => void;
}

export function PersonaSwitcher({ persona, onChange }: PersonaSwitcherProps) {
  const options: { value: Persona; label: string }[] = [
    { value: 'client', label: '👤 Client' },
    { value: 'agent', label: '🤖 Agent' },
  ];

  return (
    <div
      style={{
        display: 'flex',
        background: 'var(--bg-elevated)',
        border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-lg)',
        padding: '2px',
        gap: '2px',
        position: 'relative',
      }}
    >
      {options.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          style={{
            position: 'relative',
            background: 'transparent',
            border: 'none',
            borderRadius: 'var(--radius-md)',
            color: persona === opt.value ? 'var(--text-primary)' : 'var(--text-muted)',
            padding: '5px 14px',
            fontSize: '13px',
            fontFamily: 'var(--font-sans)',
            fontWeight: persona === opt.value ? 600 : 400,
            cursor: 'pointer',
            transition: 'color 150ms',
            zIndex: 1,
          }}
        >
          {persona === opt.value && (
            <motion.div
              layoutId="persona-indicator"
              style={{
                position: 'absolute',
                inset: 0,
                background: 'var(--bg-overlay)',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--border-default)',
                zIndex: -1,
              }}
              transition={{ duration: 0.15, ease: 'easeOut' }}
            />
          )}
          {opt.label}
        </button>
      ))}
    </div>
  );
}
