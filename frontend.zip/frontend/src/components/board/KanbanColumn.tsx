import { motion } from 'framer-motion';
import type { Task, TaskStatus } from '../../types';
import { TaskCard } from '../task/TaskCard';
import { Inbox } from 'lucide-react';

interface KanbanColumnProps {
  title: string;
  statuses: TaskStatus[];
  tasks: Task[];
  emptyIcon?: React.ReactNode;
  emptyText?: string;
  emptySubtext?: string;
}

export function KanbanColumn({
  title,
  statuses,
  tasks,
  emptyIcon,
  emptyText = 'No tasks',
  emptySubtext = '',
}: KanbanColumnProps) {
  const filtered = tasks.filter((t) => statuses.includes(t.status));

  return (
    <div
      style={{
        background: 'var(--bg-surface)',
        border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-lg)',
        display: 'flex',
        flexDirection: 'column',
        minHeight: '300px',
      }}
    >
      {/* Column header */}
      <div
        style={{
          padding: '12px 14px',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <span
          style={{
            fontSize: '11px',
            fontWeight: 600,
            color: 'var(--text-muted)',
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
          }}
        >
          {title}
        </span>
        <span
          style={{
            fontSize: '11px',
            fontFamily: 'var(--font-mono)',
            color: 'var(--text-muted)',
            background: 'var(--bg-elevated)',
            borderRadius: 'var(--radius-sm)',
            padding: '1px 6px',
          }}
        >
          {filtered.length}
        </span>
      </div>

      {/* Cards */}
      <div style={{ padding: '10px', flex: 1 }}>
        {filtered.length === 0 ? (
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '32px 16px',
              gap: '8px',
              color: 'var(--text-muted)',
            }}
          >
            {emptyIcon ?? <Inbox size={32} />}
            <span style={{ fontSize: '13px', fontWeight: 500 }}>{emptyText}</span>
            {emptySubtext && (
              <span style={{ fontSize: '12px', textAlign: 'center', lineHeight: 1.4 }}>
                {emptySubtext}
              </span>
            )}
          </div>
        ) : (
          <motion.div layout>
            {filtered.map((task) => (
              <TaskCard key={task.id} task={task} />
            ))}
          </motion.div>
        )}
      </div>
    </div>
  );
}
