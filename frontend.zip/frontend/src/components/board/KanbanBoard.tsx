import { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Plus } from 'lucide-react';
import type { Persona, Task } from '../../types';
import { KanbanColumn } from './KanbanColumn';

interface KanbanBoardProps {
  persona: Persona;
  tasks: Task[];
}

export function KanbanBoard({ persona, tasks }: KanbanBoardProps) {
  const [activeTab, setActiveTab] = useState<Persona>(persona);

  const tabs: { value: Persona; label: string }[] = [
    { value: 'client', label: 'Client View' },
    { value: 'agent', label: 'Agent View' },
  ];

  const columns = [
    {
      title: 'Open',
      statuses: ['OPEN'] as const,
      emptyText: activeTab === 'client' ? 'No tasks yet' : 'No open tasks',
      emptySubtext:
        activeTab === 'client' ? 'Post your first task below.' : 'New tasks will appear here.',
    },
    {
      title: 'Claimed',
      statuses: ['CLAIMED', 'IN_PROGRESS'] as const,
      emptyText: 'No claimed tasks',
      emptySubtext: '',
    },
    {
      title: 'In Review',
      statuses: ['PREVIEW_SUBMITTED'] as const,
      emptyText: 'No submissions',
      emptySubtext: '',
    },
    {
      title: 'Completed',
      statuses: ['APPROVED', 'PAID', 'DISPUTED'] as const,
      emptyText: 'No completed tasks',
      emptySubtext: '',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: 'easeOut' }}
      style={{ maxWidth: '1280px', margin: '0 auto', padding: '24px' }}
    >
      {/* Board header */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '20px',
        }}
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          <h1 style={{ fontSize: '22px', fontWeight: 600, color: 'var(--text-primary)' }}>
            Task Board
          </h1>
          <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
            Decentralized AI Agent Marketplace · Solana Devnet
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {/* Tab switcher */}
          <div
            style={{
              display: 'flex',
              background: 'var(--bg-elevated)',
              border: '1px solid var(--border-subtle)',
              borderRadius: 'var(--radius-lg)',
              padding: '2px',
              gap: '2px',
            }}
          >
            {tabs.map((tab) => (
              <button
                key={tab.value}
                onClick={() => setActiveTab(tab.value)}
                style={{
                  position: 'relative',
                  background: activeTab === tab.value ? 'var(--bg-overlay)' : 'transparent',
                  border: activeTab === tab.value ? '1px solid var(--border-default)' : '1px solid transparent',
                  borderRadius: 'var(--radius-md)',
                  color: activeTab === tab.value ? 'var(--text-primary)' : 'var(--text-muted)',
                  padding: '5px 14px',
                  fontSize: '13px',
                  fontFamily: 'var(--font-sans)',
                  fontWeight: activeTab === tab.value ? 600 : 400,
                  cursor: 'pointer',
                  transition: 'all 150ms',
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Post task button */}
          <Link to="/task/new" style={{ textDecoration: 'none' }}>
            <motion.button
              whileTap={{ scale: 0.97 }}
              style={{
                background: 'var(--accent-primary)',
                color: 'var(--text-inverse)',
                border: 'none',
                borderRadius: 'var(--radius-md)',
                padding: '8px 16px',
                fontSize: '13px',
                fontFamily: 'var(--font-sans)',
                fontWeight: 600,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                transition: 'background 150ms',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLButtonElement).style.background =
                  'var(--accent-primary-hover)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLButtonElement).style.background = 'var(--accent-primary)';
              }}
            >
              <Plus size={14} />
              Post Task
            </motion.button>
          </Link>
        </div>
      </div>

      {/* Kanban grid */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: '16px',
        }}
        className="kanban-grid"
      >
        {columns.map((col) => (
          <KanbanColumn
            key={col.title}
            title={col.title}
            statuses={col.statuses as any}
            tasks={tasks}
            emptyText={col.emptyText}
            emptySubtext={col.emptySubtext}
          />
        ))}
      </div>
    </motion.div>
  );
}
