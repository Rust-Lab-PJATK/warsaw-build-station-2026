import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, ArrowRight, Plus, Trash2, Bot } from 'lucide-react';
import type { TaskCategory } from '../../types';
import { Skeleton } from '../ui/card';

const CATEGORIES: TaskCategory[] = ['Research', 'Audit', 'Data', 'Code', 'Other'];

export function PostTaskForm() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    title: '',
    category: '' as TaskCategory | '',
    description: '',
    requirements: [''],
  });
  const [budget, setBudget] = useState(450);
  const [advancePct, setAdvancePct] = useState(20);
  const [estimateLoading, setEstimateLoading] = useState(false);
  const [estimateShown, setEstimateShown] = useState(false);

  const advanceAmount = Math.round((budget * advancePct) / 100);

  function handleNext() {
    setStep(2);
    if (!estimateShown) {
      setEstimateLoading(true);
      setTimeout(() => {
        setEstimateLoading(false);
        setEstimateShown(true);
      }, 1500);
    }
  }

  function addRequirement() {
    setForm((f) => ({ ...f, requirements: [...f.requirements, ''] }));
  }

  function removeRequirement(i: number) {
    setForm((f) => ({
      ...f,
      requirements: f.requirements.filter((_, idx) => idx !== i),
    }));
  }

  function updateRequirement(i: number, value: string) {
    setForm((f) => {
      const reqs = [...f.requirements];
      reqs[i] = value;
      return { ...f, requirements: reqs };
    });
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: 'easeOut' }}
      style={{ maxWidth: '640px', margin: '0 auto', padding: '24px' }}
    >
      {/* Header */}
      <div style={{ marginBottom: '24px' }}>
        <button
          onClick={() => (step === 1 ? navigate('/board') : setStep(1))}
          style={{
            background: 'none',
            border: 'none',
            color: 'var(--text-secondary)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            fontSize: '13px',
            padding: 0,
            marginBottom: '16px',
          }}
        >
          <ArrowLeft size={14} />
          {step === 1 ? 'Back to Board' : 'Back'}
        </button>
        <h1 style={{ fontSize: '22px', fontWeight: 600, color: 'var(--text-primary)' }}>
          Post New Task
        </h1>
        {/* Step indicator */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '12px' }}>
          {[1, 2].map((s) => (
            <div key={s} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div
                style={{
                  width: '24px',
                  height: '24px',
                  borderRadius: '50%',
                  background: step >= s ? 'var(--accent-primary)' : 'var(--bg-elevated)',
                  border: `1px solid ${step >= s ? 'var(--accent-primary)' : 'var(--border-default)'}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '11px',
                  fontWeight: 700,
                  color: step >= s ? 'var(--text-inverse)' : 'var(--text-muted)',
                  transition: 'all 200ms',
                }}
              >
                {s}
              </div>
              <span
                style={{
                  fontSize: '12px',
                  color: step >= s ? 'var(--text-secondary)' : 'var(--text-muted)',
                }}
              >
                {s === 1 ? 'Task Details' : 'Budget & Pricing'}
              </span>
              {s < 2 && (
                <div
                  style={{
                    width: '32px',
                    height: '1px',
                    background: step > s ? 'var(--accent-primary)' : 'var(--border-subtle)',
                    transition: 'background 200ms',
                  }}
                />
              )}
            </div>
          ))}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {step === 1 ? (
          <motion.div
            key="step1"
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 16 }}
            transition={{ duration: 0.18 }}
          >
            <Step1
              form={form}
              setForm={setForm}
              addRequirement={addRequirement}
              removeRequirement={removeRequirement}
              updateRequirement={updateRequirement}
              onNext={handleNext}
            />
          </motion.div>
        ) : (
          <motion.div
            key="step2"
            initial={{ opacity: 0, x: 16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -16 }}
            transition={{ duration: 0.18 }}
          >
            <Step2
              budget={budget}
              setBudget={setBudget}
              advancePct={advancePct}
              setAdvancePct={setAdvancePct}
              advanceAmount={advanceAmount}
              estimateLoading={estimateLoading}
              estimateShown={estimateShown}
              onBack={() => setStep(1)}
              onSubmit={() => navigate('/board')}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function fieldStyle(): React.CSSProperties {
  return {
    width: '100%',
    background: 'var(--bg-elevated)',
    border: '1px solid var(--border-default)',
    borderRadius: 'var(--radius-md)',
    color: 'var(--text-primary)',
    fontFamily: 'var(--font-sans)',
    fontSize: '14px',
    padding: '10px 12px',
    outline: 'none',
    transition: 'border-color 150ms',
    boxSizing: 'border-box',
  };
}

function labelStyle(): React.CSSProperties {
  return {
    display: 'block',
    fontSize: '11px',
    fontWeight: 600,
    color: 'var(--text-muted)',
    textTransform: 'uppercase',
    letterSpacing: '0.06em',
    marginBottom: '6px',
  };
}

function Step1({
  form,
  setForm,
  addRequirement,
  removeRequirement,
  updateRequirement,
  onNext,
}: {
  form: any;
  setForm: any;
  addRequirement: () => void;
  removeRequirement: (i: number) => void;
  updateRequirement: (i: number, v: string) => void;
  onNext: () => void;
}) {
  const canProceed =
    form.title.trim().length > 0 &&
    form.category &&
    form.description.trim().length >= 100;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* Title */}
      <div>
        <label style={labelStyle()}>Title</label>
        <input
          style={fieldStyle()}
          placeholder="e.g. Smart Contract Security Audit"
          value={form.title}
          onChange={(e) => setForm((f: any) => ({ ...f, title: e.target.value }))}
        />
      </div>

      {/* Category */}
      <div>
        <label style={labelStyle()}>Category</label>
        <select
          style={{ ...fieldStyle(), cursor: 'pointer' }}
          value={form.category}
          onChange={(e) => setForm((f: any) => ({ ...f, category: e.target.value }))}
        >
          <option value="" disabled>Select category…</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      {/* Description */}
      <div>
        <label style={labelStyle()}>
          Description
          <span style={{ color: 'var(--text-muted)', fontWeight: 400, textTransform: 'none', letterSpacing: 0, marginLeft: '6px' }}>
            ({form.description.trim().length}/100 min)
          </span>
        </label>
        <textarea
          style={{
            ...fieldStyle(),
            minHeight: '120px',
            resize: 'vertical',
            lineHeight: '1.6',
          }}
          placeholder="Describe the task in detail…"
          value={form.description}
          onChange={(e) => setForm((f: any) => ({ ...f, description: e.target.value }))}
        />
      </div>

      {/* Requirements */}
      <div>
        <label style={labelStyle()}>Requirements</label>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {form.requirements.map((req: string, i: number) => (
            <div key={i} style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
              <input
                style={{ ...fieldStyle(), flex: 1 }}
                placeholder={`Requirement ${i + 1}`}
                value={req}
                onChange={(e) => updateRequirement(i, e.target.value)}
              />
              {form.requirements.length > 1 && (
                <button
                  onClick={() => removeRequirement(i)}
                  style={{
                    background: 'none',
                    border: '1px solid var(--border-subtle)',
                    borderRadius: 'var(--radius-md)',
                    color: 'var(--accent-red)',
                    cursor: 'pointer',
                    padding: '8px',
                    display: 'flex',
                    alignItems: 'center',
                  }}
                >
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          ))}
          <button
            onClick={addRequirement}
            style={{
              background: 'none',
              border: '1px dashed var(--border-default)',
              borderRadius: 'var(--radius-md)',
              color: 'var(--text-muted)',
              cursor: 'pointer',
              padding: '8px',
              fontSize: '13px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              transition: 'border-color 150ms, color 150ms',
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--border-strong)';
              (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-secondary)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--border-default)';
              (e.currentTarget as HTMLButtonElement).style.color = 'var(--text-muted)';
            }}
          >
            <Plus size={13} />
            Add Requirement
          </button>
        </div>
      </div>

      {/* Next */}
      <motion.button
        whileTap={{ scale: 0.97 }}
        onClick={onNext}
        disabled={!canProceed}
        style={{
          background: canProceed ? 'var(--accent-primary)' : 'var(--bg-elevated)',
          color: canProceed ? 'var(--text-inverse)' : 'var(--text-muted)',
          border: 'none',
          borderRadius: 'var(--radius-md)',
          padding: '12px 24px',
          fontSize: '14px',
          fontFamily: 'var(--font-sans)',
          fontWeight: 600,
          cursor: canProceed ? 'pointer' : 'not-allowed',
          width: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '8px',
          transition: 'background 150ms',
          opacity: canProceed ? 1 : 0.4,
        }}
      >
        Continue to Budget
        <ArrowRight size={14} />
      </motion.button>
    </div>
  );
}

function Step2({
  budget,
  setBudget,
  advancePct,
  setAdvancePct,
  advanceAmount,
  estimateLoading,
  estimateShown,
  onBack,
  onSubmit,
}: {
  budget: number;
  setBudget: (v: number) => void;
  advancePct: number;
  setAdvancePct: (v: number) => void;
  advanceAmount: number;
  estimateLoading: boolean;
  estimateShown: boolean;
  onBack: () => void;
  onSubmit: () => void;
}) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      {/* AI Estimate */}
      <div
        style={{
          background: 'var(--bg-surface)',
          border: '1px solid var(--border-subtle)',
          borderRadius: 'var(--radius-lg)',
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            padding: '12px 16px',
            borderBottom: '1px solid var(--border-subtle)',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
          }}
        >
          <Bot size={13} style={{ color: 'var(--accent-primary)' }} />
          <span
            style={{
              fontSize: '11px',
              fontWeight: 600,
              color: 'var(--text-muted)',
              textTransform: 'uppercase',
              letterSpacing: '0.06em',
            }}
          >
            AI Price Estimate
          </span>
        </div>
        <div style={{ padding: '16px' }}>
          {estimateLoading ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <Skeleton style={{ height: '14px', width: '60%' }} />
              <Skeleton style={{ height: '14px', width: '80%' }} />
              <Skeleton style={{ height: '14px', width: '50%' }} />
              <Skeleton style={{ height: '14px', width: '70%' }} />
              <span
                style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '4px' }}
              >
                Analyzing similar tasks…
              </span>
            </div>
          ) : estimateShown ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                Based on 47 similar tasks on-chain:
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '14px', color: 'var(--accent-primary)', fontWeight: 600 }}>
                Suggested: 380 – 520 USDC
              </div>
              <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                <span style={{ color: 'var(--text-muted)' }}>Complexity: </span>
                <span
                  style={{
                    display: 'inline-block',
                    width: '80px',
                    height: '6px',
                    background: 'var(--bg-elevated)',
                    borderRadius: 'var(--radius-sm)',
                    verticalAlign: 'middle',
                    overflow: 'hidden',
                    marginRight: '6px',
                  }}
                >
                  <span
                    style={{
                      display: 'block',
                      width: '80%',
                      height: '100%',
                      background: 'var(--accent-amber)',
                    }}
                  />
                </span>
                High
              </div>
              <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                <span style={{ color: 'var(--text-muted)' }}>Est. time: </span>4 – 8 hours
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {/* Budget slider */}
      <div>
        <label style={labelStyle()}>
          Total Budget
          <span
            style={{
              fontFamily: 'var(--font-mono)',
              color: 'var(--accent-primary)',
              fontWeight: 600,
              fontSize: '14px',
              marginLeft: '10px',
              textTransform: 'none',
              letterSpacing: 0,
            }}
          >
            {budget} USDC
          </span>
        </label>
        <input
          type="range"
          min={50}
          max={2000}
          step={10}
          value={budget}
          onChange={(e) => setBudget(Number(e.target.value))}
          style={{ width: '100%', accentColor: 'var(--accent-primary)', cursor: 'pointer' }}
        />
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontSize: '11px',
            color: 'var(--text-muted)',
            marginTop: '4px',
          }}
        >
          <span>50 USDC</span>
          <span>2000 USDC</span>
        </div>
      </div>

      {/* Advance slider */}
      <div>
        <label style={labelStyle()}>
          Advance Payment (10–30%)
          <span
            style={{
              fontFamily: 'var(--font-mono)',
              color: 'var(--accent-amber)',
              fontWeight: 600,
              fontSize: '14px',
              marginLeft: '10px',
              textTransform: 'none',
              letterSpacing: 0,
            }}
          >
            {advancePct}% = {advanceAmount} USDC
          </span>
        </label>
        <input
          type="range"
          min={10}
          max={30}
          step={1}
          value={advancePct}
          onChange={(e) => setAdvancePct(Number(e.target.value))}
          style={{ width: '100%', accentColor: 'var(--accent-amber)', cursor: 'pointer' }}
        />
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            fontSize: '11px',
            color: 'var(--text-muted)',
            marginTop: '4px',
          }}
        >
          <span>10%</span>
          <span>30%</span>
        </div>
      </div>

      {/* Summary */}
      <div
        style={{
          background: 'var(--bg-elevated)',
          border: '1px solid var(--border-subtle)',
          borderRadius: 'var(--radius-md)',
          padding: '14px 16px',
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '10px',
        }}
      >
        <div>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '2px' }}>Total</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '18px', fontWeight: 700, color: 'var(--text-primary)' }}>
            {budget} USDC
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '2px' }}>Main Escrow</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '18px', fontWeight: 700, color: 'var(--accent-primary)' }}>
            {budget - advanceAmount} USDC
          </div>
        </div>
      </div>

      {/* Actions */}
      <div style={{ display: 'flex', gap: '10px' }}>
        <button
          onClick={onBack}
          style={{
            flex: '0 0 auto',
            background: 'var(--bg-elevated)',
            border: '1px solid var(--border-default)',
            borderRadius: 'var(--radius-md)',
            color: 'var(--text-secondary)',
            padding: '12px 20px',
            fontSize: '14px',
            fontFamily: 'var(--font-sans)',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
          }}
        >
          <ArrowLeft size={14} />
          Back
        </button>
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={onSubmit}
          style={{
            flex: 1,
            background: 'var(--accent-primary)',
            color: 'var(--text-inverse)',
            border: 'none',
            borderRadius: 'var(--radius-md)',
            padding: '12px 24px',
            fontSize: '14px',
            fontFamily: 'var(--font-sans)',
            fontWeight: 600,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '6px',
            transition: 'background 150ms',
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLButtonElement).style.background = 'var(--accent-primary-hover)';
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLButtonElement).style.background = 'var(--accent-primary)';
          }}
        >
          Post Task & Fund Escrow
          <ArrowRight size={14} />
        </motion.button>
      </div>
    </div>
  );
}
