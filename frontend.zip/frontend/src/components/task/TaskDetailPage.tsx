import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, ExternalLink } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { MOCK_TASKS } from '../../lib/mockData';
import { truncateAddress } from '../../lib/utils';
import { TaskStatusBadge } from './TaskStatusBadge';
import { ProofOfWorkPanel } from './ProofOfWorkPanel';
import { EscrowVaultPanel } from '../escrow/EscrowVaultPanel';
import { CountdownTimer } from '../escrow/CountdownTimer';
import { PrimaryActionPanel } from '../actions/PrimaryActionPanel';
import type { Persona } from '../../types';

interface TaskDetailPageProps {
  persona: Persona;
}

export function TaskDetailPage({ persona }: TaskDetailPageProps) {
  const { id } = useParams<{ id: string }>();
  const task = MOCK_TASKS.find((t) => t.id === id) ?? MOCK_TASKS[0];

  const showProof =
    task.status === 'PREVIEW_SUBMITTED' ||
    task.status === 'APPROVED' ||
    task.status === 'PAID' ||
    task.status === 'DISPUTED';

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: 'easeOut' }}
      style={{ maxWidth: '1280px', margin: '0 auto', padding: '24px 24px 80px' }}
    >
      {/* Top bar */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '24px',
        }}
      >
        <Link
          to="/board"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            color: 'var(--text-secondary)',
            textDecoration: 'none',
            fontSize: '13px',
            transition: 'color 150ms',
          }}
          onMouseEnter={(e) =>
            ((e.currentTarget as HTMLElement).style.color = 'var(--text-primary)')
          }
          onMouseLeave={(e) =>
            ((e.currentTarget as HTMLElement).style.color = 'var(--text-secondary)')
          }
        >
          <ArrowLeft size={14} />
          Back to Board
        </Link>
        <TaskStatusBadge status={task.status} />
      </div>

      {/* 2-col layout */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '1fr 380px',
          gap: '24px',
          alignItems: 'start',
        }}
        className="detail-grid"
      >
        {/* ── LEFT COLUMN ── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          {/* Task header card */}
          <div
            style={{
              background: 'var(--bg-surface)',
              border: '1px solid var(--border-subtle)',
              borderRadius: 'var(--radius-lg)',
              padding: '20px',
            }}
          >
            {/* Category + title */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                marginBottom: '10px',
              }}
            >
              <span
                style={{
                  fontSize: '11px',
                  fontWeight: 600,
                  color: 'var(--accent-blue)',
                  background: 'var(--accent-blue-dim)',
                  borderRadius: 'var(--radius-sm)',
                  padding: '2px 7px',
                  textTransform: 'uppercase',
                  letterSpacing: '0.06em',
                }}
              >
                {task.category}
              </span>
            </div>
            <h1
              style={{
                fontSize: '22px',
                fontWeight: 600,
                color: 'var(--text-primary)',
                marginBottom: '8px',
                lineHeight: 1.3,
              }}
            >
              {task.title}
            </h1>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
                Posted {formatDistanceToNow(task.txHistory[0].timestamp, { addSuffix: true })} · by{' '}
              </span>
              <a
                href={`https://explorer.solana.com/address/${task.clientAddress}?cluster=devnet`}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '11px',
                  color: 'var(--accent-blue)',
                  textDecoration: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '3px',
                }}
              >
                {truncateAddress(task.clientAddress, 4)}
                <ExternalLink size={10} />
              </a>
            </div>
          </div>

          {/* Description */}
          <div
            style={{
              background: 'var(--bg-surface)',
              border: '1px solid var(--border-subtle)',
              borderRadius: 'var(--radius-lg)',
              padding: '20px',
            }}
          >
            <div
              style={{
                fontSize: '11px',
                fontWeight: 600,
                color: 'var(--text-muted)',
                textTransform: 'uppercase',
                letterSpacing: '0.08em',
                marginBottom: '10px',
              }}
            >
              Description
            </div>
            <p
              style={{
                fontSize: '14px',
                color: 'var(--text-secondary)',
                lineHeight: 1.6,
              }}
            >
              {task.description}
            </p>
          </div>

          {/* Requirements */}
          <div
            style={{
              background: 'var(--bg-surface)',
              border: '1px solid var(--border-subtle)',
              borderRadius: 'var(--radius-lg)',
              padding: '20px',
            }}
          >
            <div
              style={{
                fontSize: '11px',
                fontWeight: 600,
                color: 'var(--text-muted)',
                textTransform: 'uppercase',
                letterSpacing: '0.08em',
                marginBottom: '12px',
              }}
            >
              Requirements
            </div>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {task.requirements.map((req, i) => (
                <li
                  key={i}
                  style={{
                    display: 'flex',
                    alignItems: 'flex-start',
                    gap: '10px',
                    fontSize: '14px',
                    color: 'var(--text-secondary)',
                  }}
                >
                  <span
                    style={{
                      width: '5px',
                      height: '5px',
                      borderRadius: '50%',
                      background: 'var(--accent-primary)',
                      flexShrink: 0,
                      marginTop: '7px',
                    }}
                  />
                  {req}
                </li>
              ))}
            </ul>
          </div>

          {/* Proof of Work */}
          {showProof && task.proofHash && <ProofOfWorkPanel task={task} />}
        </div>

        {/* ── RIGHT COLUMN ── */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <EscrowVaultPanel task={task} />
          <CountdownTimer deadline={task.deadline} />
          <TxHistoryPanel task={task} />
          <PrimaryActionPanel
            persona={persona}
            status={task.status}
            amount={task.totalAmount - task.advanceAmount}
            currency={task.currency}
          />
        </div>
      </div>

      {/* Mobile sticky CTA */}
      <div className="mobile-sticky-cta">
        <PrimaryActionPanel
          persona={persona}
          status={task.status}
          amount={task.totalAmount - task.advanceAmount}
          currency={task.currency}
        />
      </div>
    </motion.div>
  );
}

function TxHistoryPanel({ task }: { task: import('../../types').Task }) {
  return (
    <div
      style={{
        background: 'var(--bg-surface)',
        border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-lg)',
        overflow: 'hidden',
      }}
    >
      <div
        style={{
          padding: '14px 16px 12px',
          borderBottom: '1px solid var(--border-subtle)',
        }}
      >
        <span
          style={{
            fontSize: '11px',
            fontWeight: 600,
            color: 'var(--text-muted)',
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
          }}
        >
          TX History
        </span>
      </div>
      <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {task.txHistory.map((tx, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span
              style={{
                width: '6px',
                height: '6px',
                borderRadius: '50%',
                background: 'var(--accent-primary)',
                flexShrink: 0,
              }}
            />
            <span style={{ fontSize: '12px', color: 'var(--text-secondary)', flex: 1 }}>
              {tx.event}
            </span>
            <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <a
                href={`https://explorer.solana.com/tx/${tx.txHash}?cluster=devnet`}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '11px',
                  color: 'var(--accent-blue)',
                  textDecoration: 'none',
                }}
              >
                {tx.txHash}
              </a>
              <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
                · {formatDistanceToNow(tx.timestamp, { addSuffix: true })}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
