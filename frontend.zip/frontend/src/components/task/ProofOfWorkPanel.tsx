import { ShieldCheck, ExternalLink } from 'lucide-react';
import type { Task } from '../../types';

interface ProofOfWorkPanelProps {
  task: Task;
}

export function ProofOfWorkPanel({ task }: ProofOfWorkPanelProps) {
  const resultTx = task.txHistory.find((tx) => tx.event === 'Proof submitted');

  return (
    <div
      style={{
        background: 'var(--bg-surface)',
        border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-lg)',
        overflow: 'hidden',
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: '14px 16px 12px',
          borderBottom: '1px solid var(--border-subtle)',
        }}
      >
        <span
          style={{
            fontSize: '11px',
            fontWeight: 600,
            color: 'var(--text-muted)',
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
          }}
        >
          Proof of Work
        </span>
      </div>

      {/* Content */}
      <div style={{ padding: '16px' }}>
        {/* Preview area */}
        <div
          style={{
            background: 'var(--bg-elevated)',
            border: '1px solid var(--border-subtle)',
            borderRadius: 'var(--radius-md)',
            padding: '16px',
            maxHeight: '280px',
            overflow: 'auto',
            marginBottom: '16px',
            fontFamily: 'var(--font-mono)',
            fontSize: '12px',
            color: 'var(--text-secondary)',
            lineHeight: '1.7',
          }}
        >
          <div style={{ color: 'var(--accent-primary)', marginBottom: '8px', fontWeight: 600 }}>
            // Security Audit Report — Smart Contract v2.1.0
          </div>
          <div style={{ color: 'var(--text-muted)' }}>
            {'/** FINDINGS SUMMARY\n'}
            {' * [CRITICAL]  0 issues\n'}
            {' * [HIGH]      1 issue  — Integer overflow in transfer_tokens\n'}
            {' * [MEDIUM]    2 issues — Access control on admin_withdraw\n'}
            {' * [LOW]       3 issues — Missing event emissions\n'}
            {' * [INFO]      5 notes  — Code style recommendations\n'}
            {' */\n\n'}
          </div>
          <div>
            <span style={{ color: 'var(--accent-amber)' }}>HIGH SEVERITY</span>
            <span style={{ color: 'var(--text-secondary)' }}>
              {': transfer_tokens() does not validate u64 arithmetic,\n'}
              {'allowing overflow when amount > u64::MAX / 2. Recommend\n'}
              {'using checked_add() and checked_mul() throughout.\n\n'}
            </span>
          </div>
          <div>
            <span style={{ color: 'var(--text-muted)' }}>
              {'Full report: 14 pages · Submitted via IPFS\n'}
              {'CID: QmX7d3...kP9mR2\n'}
            </span>
          </div>
        </div>

        {/* ZK Proof Hash */}
        <div style={{ marginBottom: '12px' }}>
          <div
            style={{
              fontSize: '11px',
              color: 'var(--text-muted)',
              textTransform: 'uppercase',
              letterSpacing: '0.06em',
              fontWeight: 600,
              marginBottom: '6px',
            }}
          >
            ZK Proof Hash
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '12px',
                color: 'var(--text-primary)',
                background: 'var(--bg-elevated)',
                border: '1px solid var(--border-subtle)',
                borderRadius: 'var(--radius-sm)',
                padding: '6px 10px',
                flex: 1,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
            >
              {task.proofHash}
            </span>
            {task.zkVerified && (
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  background: 'var(--accent-primary-dim)',
                  border: '1px solid rgba(0, 229, 160, 0.2)',
                  borderRadius: 'var(--radius-sm)',
                  padding: '5px 8px',
                  flexShrink: 0,
                }}
              >
                <ShieldCheck size={12} style={{ color: 'var(--accent-primary)' }} />
                <span
                  style={{
                    fontSize: '11px',
                    color: 'var(--accent-primary)',
                    fontWeight: 600,
                    letterSpacing: '0.04em',
                    textTransform: 'uppercase',
                  }}
                >
                  Verified
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Result TX */}
        {resultTx && (
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
            }}
          >
            <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Result TX:</span>
            <a
              href={`https://explorer.solana.com/tx/${resultTx.txHash}?cluster=devnet`}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '12px',
                color: 'var(--accent-blue)',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                textDecoration: 'none',
              }}
            >
              {resultTx.txHash}
              <ExternalLink size={11} />
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
