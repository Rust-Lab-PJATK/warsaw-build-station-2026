import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import type { Task } from '../../types';
import { TaskStatusBadge } from './TaskStatusBadge';

interface TaskCardProps {
  task: Task;
}

function getTimeLeft(deadline: Date): string {
  const ms = deadline.getTime() - Date.now();
  if (ms <= 0) return 'Expired';
  const h = Math.floor(ms / 3600_000);
  const m = Math.floor((ms % 3600_000) / 60_000);
  if (h > 0) return `${h}h left`;
  return `${m}m left`;
}

function getTimeLeftColor(deadline: Date): string {
  const ms = deadline.getTime() - Date.now();
  if (ms <= 0) return 'var(--accent-red)';
  if (ms < 60 * 60_000) return 'var(--accent-amber)';
  return 'var(--text-secondary)';
}

export function TaskCard({ task }: TaskCardProps) {
  return (
    <motion.div layout="position" transition={{ duration: 0.25 }}>
      <Link to={`/task/${task.id}`} style={{ textDecoration: 'none' }}>
        <motion.div
          whileHover={{ borderColor: 'var(--border-default)' }}
          whileTap={{ scale: 0.98 }}
          style={{
            background: 'var(--bg-surface)',
            border: '1px solid var(--border-subtle)',
            borderRadius: 'var(--radius-lg)',
            padding: '14px',
            cursor: 'pointer',
            transition: 'border-color 150ms, background 150ms',
            marginBottom: '8px',
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLDivElement).style.background = 'var(--bg-elevated)';
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLDivElement).style.background = 'var(--bg-surface)';
          }}
        >
          {/* Header row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
            <TaskStatusBadge status={task.status} />
            <span
              style={{
                fontSize: '13px',
                fontWeight: 600,
                color: 'var(--text-primary)',
                flex: 1,
                overflow: 'hidden',
                whiteSpace: 'nowrap',
                textOverflow: 'ellipsis',
              }}
            >
              {task.title}
            </span>
          </div>

          {/* Description */}
          <p
            style={{
              fontSize: '12px',
              color: 'var(--text-secondary)',
              lineHeight: '1.5',
              marginBottom: '12px',
              display: '-webkit-box',
              WebkitLineClamp: 2,
              WebkitBoxOrient: 'vertical',
              overflow: 'hidden',
            }}
          >
            {task.description}
          </p>

          {/* Divider */}
          <div
            style={{ height: '1px', background: 'var(--border-subtle)', marginBottom: '10px' }}
          />

          {/* Footer */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: '12px' }}>
              <span
                style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '12px',
                  color: 'var(--accent-primary)',
                  fontWeight: 500,
                }}
              >
                {task.totalAmount} {task.currency}
              </span>
              <span
                style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '12px',
                  color: getTimeLeftColor(task.deadline),
                }}
              >
                ⏱ {getTimeLeft(task.deadline)}
              </span>
            </div>
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '11px',
                color: 'var(--text-muted)',
              }}
            >
              {formatDistanceToNow(task.txHistory[0].timestamp, { addSuffix: true })}
            </span>
          </div>
        </motion.div>
      </Link>
    </motion.div>
  );
}
