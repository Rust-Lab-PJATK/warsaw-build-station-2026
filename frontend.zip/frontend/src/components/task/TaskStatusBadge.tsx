import { motion, AnimatePresence } from 'framer-motion';
import type { TaskStatus } from '../../types';

interface TaskStatusBadgeProps {
  status: TaskStatus;
}

const STATUS_CONFIG: Record<
  TaskStatus,
  { bg: string; color: string; dot: boolean; pulse: boolean; label: string }
> = {
  OPEN: {
    bg: 'var(--bg-elevated)',
    color: 'var(--text-secondary)',
    dot: true,
    pulse: false,
    label: 'Open',
  },
  CLAIMED: {
    bg: 'var(--accent-amber-dim)',
    color: 'var(--accent-amber)',
    dot: true,
    pulse: true,
    label: 'Claimed',
  },
  IN_PROGRESS: {
    bg: 'var(--accent-amber-dim)',
    color: 'var(--accent-amber)',
    dot: true,
    pulse: true,
    label: 'In Progress',
  },
  PREVIEW_SUBMITTED: {
    bg: 'var(--accent-blue-dim)',
    color: 'var(--accent-blue)',
    dot: true,
    pulse: true,
    label: 'In Review',
  },
  APPROVED: {
    bg: 'var(--accent-primary-dim)',
    color: 'var(--accent-primary)',
    dot: true,
    pulse: false,
    label: 'Approved',
  },
  PAID: {
    bg: 'var(--accent-primary-dim)',
    color: 'var(--accent-primary)',
    dot: false,
    pulse: false,
    label: 'Paid',
  },
  DISPUTED: {
    bg: 'var(--accent-red-dim)',
    color: 'var(--accent-red)',
    dot: true,
    pulse: true,
    label: 'Disputed',
  },
};

export function TaskStatusBadge({ status }: TaskStatusBadgeProps) {
  const config = STATUS_CONFIG[status];

  return (
    <AnimatePresence mode="wait">
      <motion.span
        key={status}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.15 }}
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '6px',
          background: config.bg,
          color: config.color,
          borderRadius: 'var(--radius-sm)',
          padding: '3px 8px',
          fontSize: '11px',
          fontFamily: 'var(--font-sans)',
          fontWeight: 600,
          letterSpacing: '0.04em',
          textTransform: 'uppercase',
          border: `1px solid ${config.color}22`,
        }}
      >
        {config.dot && (
          <span
            className={config.pulse ? 'dot-pulse' : undefined}
            style={{
              width: '5px',
              height: '5px',
              borderRadius: '50%',
              background: config.color,
              flexShrink: 0,
            }}
          />
        )}
        {config.label}
      </motion.span>
    </AnimatePresence>
  );
}
