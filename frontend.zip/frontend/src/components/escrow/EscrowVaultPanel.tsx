import { motion, useSpring, useMotionValue } from 'framer-motion';
import { Vault, Copy, ExternalLink } from 'lucide-react';
import { useEffect, useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import type { Task } from '../../types';
import { useEscrowBalance } from '../../hooks/useEscrowBalance';
import { truncateAddress } from '../../lib/utils';

interface EscrowVaultPanelProps {
  task: Task;
}

export function EscrowVaultPanel({ task }: EscrowVaultPanelProps) {
  const { escrowData, isLive, lastUpdated } = useEscrowBalance(task);
  const [copied, setCopied] = useState(false);

  const advancePct = (escrowData.advanceReleased / escrowData.totalAmount) * 100;
  const mainPct = (escrowData.mainLocked / escrowData.totalAmount) * 100;

  const handleCopy = () => {
    navigator.clipboard.writeText(task.escrowAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div
      style={{
        background: 'var(--bg-surface)',
        border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-lg)',
        overflow: 'hidden',
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: '14px 16px 12px',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <span
          style={{
            fontSize: '11px',
            fontWeight: 600,
            color: 'var(--text-muted)',
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
          }}
        >
          Escrow Vault
        </span>
        <Vault size={14} style={{ color: 'var(--text-muted)' }} />
      </div>

      {/* Body */}
      <div style={{ padding: '16px' }}>
        {/* Amount */}
        <div style={{ marginBottom: '4px' }}>
          <AnimatedAmount value={escrowData.totalAmount} currency={task.currency} />
        </div>

        {/* Address */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            marginBottom: '16px',
          }}
        >
          <span
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '11px',
              color: 'var(--text-muted)',
            }}
          >
            vault: {truncateAddress(task.escrowAddress, 4)}
          </span>
          <button
            onClick={handleCopy}
            style={{
              background: 'none',
              border: 'none',
              color: 'var(--text-muted)',
              cursor: 'pointer',
              padding: '0',
              display: 'flex',
              alignItems: 'center',
            }}
            title="Copy address"
          >
            <Copy size={11} />
          </button>
          {copied && (
            <span style={{ fontSize: '10px', color: 'var(--accent-primary)' }}>Copied!</span>
          )}
          <a
            href={`https://explorer.solana.com/address/${task.escrowAddress}?cluster=devnet`}
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: 'var(--accent-blue)', display: 'flex', alignItems: 'center' }}
          >
            <ExternalLink size={11} />
          </a>
        </div>

        {/* Progress bar */}
        <div style={{ marginBottom: '8px' }}>
          <div
            style={{
              height: '8px',
              borderRadius: 'var(--radius-sm)',
              background: 'var(--bg-elevated)',
              display: 'flex',
              overflow: 'hidden',
              border: '1px solid var(--border-subtle)',
            }}
          >
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${advancePct}%` }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              style={{
                background: 'var(--accent-amber)',
                height: '100%',
                position: 'relative',
              }}
            />
            <div
              style={{
                width: '1px',
                background: 'rgba(255,255,255,0.3)',
                flexShrink: 0,
              }}
            />
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${mainPct}%` }}
              transition={{ duration: 0.6, ease: 'easeOut', delay: 0.1 }}
              style={{
                background: 'var(--accent-primary)',
                height: '100%',
              }}
            />
          </div>
        </div>

        {/* Labels */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '8px',
            marginBottom: '16px',
          }}
        >
          <div>
            <div
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '12px',
                color: 'var(--accent-amber)',
                fontWeight: 500,
              }}
            >
              Advance · {escrowData.advanceReleased} {task.currency}
            </div>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginTop: '2px' }}>
              Released ✓
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '12px',
                color: 'var(--accent-primary)',
                fontWeight: 500,
              }}
            >
              Main · {escrowData.mainLocked} {task.currency}
            </div>
            <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginTop: '2px' }}>
              Locked 🔒
            </div>
          </div>
        </div>

        {/* Footer */}
        <div
          style={{
            borderTop: '1px solid var(--border-subtle)',
            paddingTop: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <span style={{ fontSize: '11px', color: 'var(--text-muted)' }}>
            Updated {formatDistanceToNow(lastUpdated, { addSuffix: true })}
          </span>
          <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
            <span
              className="live-dot"
              style={{
                width: '6px',
                height: '6px',
                borderRadius: '50%',
                background: isLive ? 'var(--accent-primary)' : 'var(--text-muted)',
              }}
            />
            <span style={{ fontSize: '10px', color: 'var(--text-muted)' }}>
              {isLive ? 'live' : 'cached'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

function AnimatedAmount({ value, currency }: { value: number; currency: string }) {
  const motionVal = useMotionValue(value);
  const spring = useSpring(motionVal, { stiffness: 100, damping: 30 });
  const [display, setDisplay] = useState(value);

  useEffect(() => {
    motionVal.set(value);
  }, [value, motionVal]);

  useEffect(() => {
    return spring.on('change', (v) => setDisplay(Math.round(v * 100) / 100));
  }, [spring]);

  return (
    <span
      style={{
        fontFamily: 'var(--font-mono)',
        fontSize: '32px',
        fontWeight: 700,
        color: 'var(--text-primary)',
        letterSpacing: '-0.02em',
      }}
    >
      {display.toFixed(2)}{' '}
      <span style={{ fontSize: '16px', color: 'var(--text-secondary)', fontWeight: 500 }}>
        {currency}
      </span>
    </span>
  );
}
