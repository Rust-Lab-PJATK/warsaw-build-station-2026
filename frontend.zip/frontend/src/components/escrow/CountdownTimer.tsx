import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { Clock } from 'lucide-react';
import { useCountdown } from '../../hooks/useCountdown';

interface CountdownTimerProps {
  deadline: Date;
}

function pad(n: number): string {
  return String(n).padStart(2, '0');
}

export function CountdownTimer({ deadline }: CountdownTimerProps) {
  const { hours, minutes, seconds, expired, totalMs } = useCountdown(deadline);

  const isAmber = !expired && totalMs < 2 * 3600_000;
  const isRed = expired || totalMs < 15 * 60_000;
  const color = isRed
    ? 'var(--accent-red)'
    : isAmber
    ? 'var(--accent-amber)'
    : 'var(--text-primary)';

  return (
    <div
      style={{
        background: 'var(--bg-surface)',
        border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-lg)',
        overflow: 'hidden',
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: '14px 16px 12px',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
        }}
      >
        <Clock size={12} style={{ color: 'var(--text-muted)' }} />
        <span
          style={{
            fontSize: '11px',
            fontWeight: 600,
            color: 'var(--text-muted)',
            textTransform: 'uppercase',
            letterSpacing: '0.08em',
          }}
        >
          Submit Deadline
        </span>
      </div>

      {/* Timer */}
      <motion.div
        className={isRed && !expired ? 'pulse-component' : undefined}
        style={{ padding: '16px', textAlign: 'center' }}
      >
        {expired ? (
          <div
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '20px',
              fontWeight: 700,
              color: 'var(--accent-red)',
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
            }}
          >
            DEADLINE EXCEEDED
          </div>
        ) : (
          <div
            style={{
              display: 'flex',
              alignItems: 'flex-end',
              justifyContent: 'center',
              gap: '4px',
            }}
          >
            {[
              { val: pad(hours), unit: 'hrs' },
              { val: ':', unit: null },
              { val: pad(minutes), unit: 'min' },
              { val: ':', unit: null },
              { val: pad(seconds), unit: 'sec' },
            ].map((item, i) => (
              <div
                key={i}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  lineHeight: '1',
                }}
              >
                <span
                  style={{
                    fontFamily: 'var(--font-mono)',
                    fontSize: item.unit ? '40px' : '36px',
                    fontWeight: 700,
                    color,
                    letterSpacing: '-0.02em',
                    marginBottom: item.unit ? '4px' : '8px',
                  }}
                >
                  {item.val}
                </span>
                {item.unit && (
                  <span
                    style={{
                      fontFamily: 'var(--font-sans)',
                      fontSize: '10px',
                      color: 'var(--text-muted)',
                      letterSpacing: '0.04em',
                      textTransform: 'uppercase',
                    }}
                  >
                    {item.unit}
                  </span>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Absolute date */}
        <div
          style={{
            marginTop: '10px',
            fontSize: '11px',
            color: 'var(--text-muted)',
            fontFamily: 'var(--font-mono)',
          }}
        >
          {format(deadline, "MMM d, yyyy · HH:mm 'UTC'")}
        </div>
      </motion.div>
    </div>
  );
}
