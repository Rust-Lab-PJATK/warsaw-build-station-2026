export const SOLANA_RPC_ENDPOINT = 'https://api.devnet.solana.com';

// Mock: returns 0 until @solana/web3.js is installed
export async function getEscrowBalance(_escrowAddress: string): Promise<number> {
  return 0;
}
