import type { Task, TaskStatus } from '../types';

export const MOCK_TASK: Task = {
  id: 'task_7xKpQm',
  title: 'Smart Contract Security Audit',
  category: 'Audit',
  description:
    'Analyze the provided Solana program for reentrancy vulnerabilities, integer overflows, and unauthorized account access patterns.',
  requirements: [
    'Full reentrancy analysis',
    'Integer overflow detection',
    'Access control review',
    'Written report with severity ratings',
  ],
  status: 'PREVIEW_SUBMITTED' as TaskStatus,
  totalAmount: 450,
  advanceAmount: 50,
  currency: 'USDC',
  deadline: new Date(Date.now() + 4 * 60 * 60 * 1000 + 23 * 60 * 1000),
  clientAddress: '8xKpQm3mNrAbCd4eFgHiJk5lMnOpQrSt',
  agentAddress: '3mNrAb7xKpQmCd4eFgHiJk5lMnOpQrSt',
  escrowAddress: 'Esc1234abcd5678efgh9012ijkl3456mn',
  proofHash: '0x4a3fc2d1e8b9f07a2c5d6e1f3a8b2c9d4e7f0a1b',
  zkVerified: true,
  txHistory: [
    {
      event: 'Escrow funded',
      txHash: 'a8d3...11fe',
      timestamp: new Date(Date.now() - 3 * 3600_000),
    },
    {
      event: 'Agent claimed',
      txHash: 'b9e4...22gh',
      timestamp: new Date(Date.now() - 1 * 3600_000),
    },
    {
      event: 'Advance released',
      txHash: 'c0f5...33ij',
      timestamp: new Date(Date.now() - 58 * 60_000),
    },
    {
      event: 'Proof submitted',
      txHash: 'd1g6...44kl',
      timestamp: new Date(Date.now() - 12 * 60_000),
    },
  ],
};

export const MOCK_TASKS: Task[] = [
  MOCK_TASK,
  {
    id: 'task_3mNrAb',
    title: 'DeFi Protocol Research Report',
    category: 'Research',
    description:
      'Comprehensive analysis of top 10 Solana DeFi protocols by TVL, including risk assessment and yield comparison.',
    requirements: [
      'TVL analysis for top 10 protocols',
      'Risk scoring matrix',
      'Yield comparison table',
      'Executive summary (2 pages)',
    ],
    status: 'OPEN',
    totalAmount: 280,
    advanceAmount: 28,
    currency: 'USDC',
    deadline: new Date(Date.now() + 6 * 60 * 60 * 1000),
    clientAddress: '5pQrSt8xKpQm3mNrAbCd4eFgHiJk5lMn',
    escrowAddress: 'Esc9876mnop5432qrst1098uvwx6543yz',
    txHistory: [
      {
        event: 'Task posted',
        txHash: 'e2h7...55mn',
        timestamp: new Date(Date.now() - 30 * 60_000),
      },
    ],
  },
  {
    id: 'task_9kLmNo',
    title: 'NFT Metadata Indexer',
    category: 'Code',
    description:
      'Build an off-chain indexer that tracks NFT metadata changes on Solana and exposes a REST API.',
    requirements: [
      'WebSocket subscription to Solana RPC',
      'PostgreSQL schema for metadata storage',
      'REST API with pagination',
      'Docker deployment config',
    ],
    status: 'CLAIMED',
    totalAmount: 750,
    advanceAmount: 75,
    currency: 'USDC',
    deadline: new Date(Date.now() + 12 * 60 * 60 * 1000),
    clientAddress: '2cDeFg9kLmNoAbCd4eFgHiJk5lMnOpQrSt',
    agentAddress: '7hIjKl3mNrAb4eFgHiJk5lMnOpQrStUvWx',
    escrowAddress: 'Esc5555pppp6666qqqq7777rrrr8888ssss',
    txHistory: [
      {
        event: 'Task posted',
        txHash: 'f3i8...66op',
        timestamp: new Date(Date.now() - 5 * 3600_000),
      },
      {
        event: 'Agent claimed',
        txHash: 'g4j9...77qr',
        timestamp: new Date(Date.now() - 2 * 3600_000),
      },
    ],
  },
  {
    id: 'task_2pQrSt',
    title: 'On-chain Price Feed Aggregator',
    category: 'Data',
    description:
      'Aggregate price feeds from Pyth, Switchboard, and Chainlink Solana adapters into a unified on-chain account.',
    requirements: [
      'Multi-oracle price aggregation',
      'Confidence interval calculation',
      'TWAP over 15-min windows',
      'Anchor program + TypeScript SDK',
    ],
    status: 'APPROVED',
    totalAmount: 600,
    advanceAmount: 60,
    currency: 'USDC',
    deadline: new Date(Date.now() - 2 * 60 * 60 * 1000),
    clientAddress: '4eFgHi2pQrStAbCd4eFgHiJk5lMnOpQrSt',
    agentAddress: '6hIjKl8xKpQmCd4eFgHiJk5lMnOpQrStUv',
    escrowAddress: 'Esc1111aaaa2222bbbb3333cccc4444dddd',
    proofHash: '0x9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b0c',
    zkVerified: true,
    txHistory: [
      {
        event: 'Task posted',
        txHash: 'h5k0...88st',
        timestamp: new Date(Date.now() - 10 * 3600_000),
      },
      {
        event: 'Agent claimed',
        txHash: 'i6l1...99uv',
        timestamp: new Date(Date.now() - 8 * 3600_000),
      },
      {
        event: 'Advance released',
        txHash: 'j7m2...00wx',
        timestamp: new Date(Date.now() - 7 * 3600_000),
      },
      {
        event: 'Proof submitted',
        txHash: 'k8n3...11yz',
        timestamp: new Date(Date.now() - 3 * 3600_000),
      },
      {
        event: 'Task approved',
        txHash: 'l9o4...22ab',
        timestamp: new Date(Date.now() - 30 * 60_000),
      },
    ],
  },
];
