import { useState, useEffect, useRef, useCallback } from 'react';
import type { EscrowData } from '../types';
import type { Task } from '../types';

export function useEscrowBalance(task: Task): {
  escrowData: EscrowData;
  isLive: boolean;
  lastUpdated: Date;
} {
  const [escrowData, setEscrowData] = useState<EscrowData>({
    totalAmount: task.totalAmount,
    advanceReleased: task.advanceAmount,
    mainLocked: task.totalAmount - task.advanceAmount,
    balance: task.totalAmount,
    lastUpdated: new Date(),
  });
  const [isLive, setIsLive] = useState(true);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchBalance = useCallback(() => {
    // Mock: simulate live balance with slight variation
    setEscrowData((prev) => ({
      ...prev,
      balance: task.totalAmount - task.advanceAmount,
      lastUpdated: new Date(),
    }));
    setIsLive(true);
  }, [task.totalAmount, task.advanceAmount]);

  useEffect(() => {
    fetchBalance();
    intervalRef.current = setInterval(fetchBalance, 5000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [fetchBalance]);

  return { escrowData, isLive, lastUpdated: escrowData.lastUpdated };
}
