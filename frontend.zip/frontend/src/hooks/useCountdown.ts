import { useState, useEffect, useRef } from 'react';

interface TimeLeft {
  hours: number;
  minutes: number;
  seconds: number;
  expired: boolean;
  totalMs: number;
}

export function useCountdown(deadline: Date): TimeLeft {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>(() => calculate(deadline));
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    setTimeLeft(calculate(deadline));
    intervalRef.current = setInterval(() => {
      setTimeLeft(calculate(deadline));
    }, 1000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [deadline]);

  return timeLeft;
}

function calculate(deadline: Date): TimeLeft {
  const totalMs = deadline.getTime() - Date.now();
  if (totalMs <= 0) {
    return { hours: 0, minutes: 0, seconds: 0, expired: true, totalMs: 0 };
  }
  const totalSeconds = Math.floor(totalMs / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return { hours, minutes, seconds, expired: false, totalMs };
}
