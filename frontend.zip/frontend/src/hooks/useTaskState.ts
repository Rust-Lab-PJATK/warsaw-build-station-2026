import { useState, useCallback } from 'react';
import type { Task, TaskStatus } from '../types';
import { MOCK_TASKS } from '../lib/mockData';

export function useTaskState() {
  const [tasks, setTasks] = useState<Task[]>(MOCK_TASKS);

  const updateTaskStatus = useCallback((taskId: string, status: TaskStatus) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, status } : t))
    );
  }, []);

  const getTask = useCallback(
    (taskId: string) => tasks.find((t) => t.id === taskId),
    [tasks]
  );

  return { tasks, updateTaskStatus, getTask };
}
