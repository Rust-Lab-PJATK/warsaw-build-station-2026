import { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Header } from './components/layout/Header';
import { KanbanBoard } from './components/board/KanbanBoard';
import { TaskDetailPage } from './components/task/TaskDetailPage';
import { PostTaskForm } from './components/task/PostTaskForm';
import { useTaskState } from './hooks/useTaskState';
import type { Persona } from './types';

export default function App() {
  const [persona, setPersona] = useState<Persona>('client');
  const { tasks } = useTaskState();

  return (
    <BrowserRouter>
      <div style={{ minHeight: '100vh', background: 'var(--bg-base)', display: 'flex', flexDirection: 'column' }}>
        <Header
          persona={persona}
          onPersonaChange={setPersona}
          walletAddress="7xKpQm3mNrAbCd4e"
        />
        <main style={{ flex: 1 }}>
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={<Navigate to="/board" replace />} />
              <Route
                path="/board"
                element={
                  <motion.div
                    key="board"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                  >
                    <KanbanBoard persona={persona} tasks={tasks} />
                  </motion.div>
                }
              />
              <Route
                path="/task/new"
                element={
                  <motion.div
                    key="new-task"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                  >
                    <PostTaskForm />
                  </motion.div>
                }
              />
              <Route
                path="/task/new"
                element={
                  <motion.div
                    key="new-task"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                  >
                    <PostTaskForm />
                  </motion.div>
                }
              />
              <Route
                path="/task/:id"
                element={
                  <motion.div
                    key="task-detail"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.15 }}
                  >
                    <TaskDetailPage persona={persona} />
                  </motion.div>
                }
              />
            </Routes>
          </AnimatePresence>
        </main>
      </div>
    </BrowserRouter>
  );
}
